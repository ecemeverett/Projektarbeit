Please run the following commands in order to activate and install all required packages.
C:\Path\To\Python\python.exe -m venv myenv  (Please change the path with your path to pyhton.exe)
myenv\Scripts\activate
pip install -r requirements.txt